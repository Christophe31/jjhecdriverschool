<?php

/**
 * Product form.
 *
 * @package    form
 * @subpackage product
 * @version    SVN: $Id: ProductForm.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class ProductForm extends BaseProductForm
{
  public function configure()
  {
  }
}
