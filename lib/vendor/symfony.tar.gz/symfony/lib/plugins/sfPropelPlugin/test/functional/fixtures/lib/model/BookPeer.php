<?php

/**
 * Subclass for performing query and update operations on the 'book' table.
 *
 * 
 *
 * @package lib.model
 */ 
class BookPeer extends BaseBookPeer
{
}
