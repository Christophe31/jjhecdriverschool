<?php

/**
 * Author form.
 *
 * @package    form
 * @subpackage author
 * @version    SVN: $Id: AuthorForm.class.php 6884 2008-01-02 10:32:24Z dwhittle $
 */
class AuthorForm extends BaseAuthorForm
{
  public function configure()
  {
  }
}
