<?php

/**
 * Subclass for representing a row from the 'movie_i18n' table.
 *
 * 
 *
 * @package lib.model
 */ 
class MovieI18n extends BaseMovieI18n
{
}
