<?php

/**
 * Book form.
 *
 * @package    form
 * @subpackage book
 * @version    SVN: $Id: BookForm.class.php 6884 2008-01-02 10:32:24Z dwhittle $
 */
class BookForm extends BaseBookForm
{
  public function configure()
  {
  }
}
