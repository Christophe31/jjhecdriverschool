<?php

/**
 * Project filter form base class.
 *
 * @package    ##PROJECT_NAME##
 * @subpackage filter
 * @author     Your name here
 * @version    SVN: $Id: BaseFormFilterPropel.class.php 23306 2009-10-24 13:59:13Z Kris.Wallsmith $
 */
abstract class BaseFormFilterPropel extends sfFormFilterPropel
{
  public function setup()
  {
  }
}
