<?php

/**
 * Subclass for performing query and update operations on the 'article' table.
 *
 * 
 *
 * @package lib.model
 */ 
class ArticlePeer extends BaseArticlePeer
{
}
