<?php

/**
 * Subclass for performing query and update operations on the 'attachment' table.
 *
 * 
 *
 * @package lib.model
 */ 
class AttachmentPeer extends BaseAttachmentPeer
{
}
