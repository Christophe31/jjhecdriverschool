<?php

/**
 * Category form.
 *
 * @package    form
 * @subpackage category
 * @version    SVN: $Id: CategoryForm.class.php 6884 2008-01-02 10:32:24Z dwhittle $
 */
class CategoryForm extends BaseCategoryForm
{
  public function configure()
  {
  }
}
