<?php

/**
 * Subclass for performing query and update operations on the 'movie' table.
 *
 * 
 *
 * @package lib.model
 */ 
class MoviePeer extends BaseMoviePeer
{
}
